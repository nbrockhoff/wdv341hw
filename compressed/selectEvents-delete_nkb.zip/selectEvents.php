<?php
          
            include('dbconnect.php'); 
          
          try {
          $stmt = $DB->prepare('SELECT * FROM wdv341_event');


          $stmt->execute();

          $result = $stmt->fetchAll();



             foreach ($result as $row) {
                  $displayResult .=  "<tr>";
                  $displayResult .=  "<td>" . $row['event_name'] . "</td>";
                  $displayResult .=  "<td>" . $row['event_description'] . " </td>";
                  $displayResult .=  "<td>" . $row['event_presenter'] . "</td>";
                  $displayResult .=  "<td>" . $row['event_date'] . "</td>";
                  $displayResult .=  "<td>" . $row['event_time'] . "</td>";

                  //$displayResult .=  "<td><a href='eventEdit.php?recID=" . $row['event_id'] . "'>Edit Event</a></td>";
                  $displayResult .=  "<td><a href='eventDelete.php?event_id=" . $row['event_id'] . "'>Delete Event</a></td>";
                  $displayResult .=  "</tr>";
                }
              
          } catch(PDOException $e) {
          echo 'Error: ' . $e->getMessage();
           }
        
      
   ?>

<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>N.Brockhoff | Select Events</title>
<link rel="stylesheet" href="css/app.css">
</head>
<body>
 
<div class="top-bar">
    <div class="top-bar-left">
        <ul class="menu">
            <li class="menu-text">N.Brockhoff | Fall 2016</li>
            <li><a href="index.html">WDV341</a></li>
        </ul>
    </div>
</div>
 
<div class="callout large primary">
    <div class="row column text-center">

        <h1>Select Events</h1>
        
    </div>
</div>

 <div class="row">
  <div class="small-12 columns">


    <div id="success" class="success">
     <h5><?php echo $successMsg; ?></h5>
     <div class="submitted_data">
      <table>
        <?php echo $submittedData; ?>
      </table>
    </div>
  </div>

    <div id="error" class="error">
      <h5><?php echo $errorMsg; ?></h5>
    </div>
  </div>
</div>




<table border='2'>
            <tr>
            <th>Event</th>
            <th>Description</th>
            <th>Educator</th>
            <th>Date</th>
            <th>Time</th>
            <!--<th>Edit</th>-->
            <th>Delete</th>
            </tr>
         


<?php echo $displayResult; ?>
          </table>
  </div>
</form>

  
    
</div>
</div>
<p>&nbsp;</p>
</body>
</html>
