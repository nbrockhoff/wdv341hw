<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>N.Brockhoff | PHP Functions</title>
<link rel="stylesheet" href="css/app.css">
    
</head>
<body>
<div class="top-bar">
    <div class="top-bar-left">
        <ul class="menu">
            <li class="menu-text">N.Brockhoff | Fall 2016</li>
            <li><a href="index.html">WDV341</a></li>
        </ul>
    </div>
</div>
 
<div class="callout large primary">
    <div class="row column text-center">

        <h1>PHP Functions</h1>
        
    </div>
</div>
 <div class="row">
 <div class="small-10 small-offset-1 columns">
<form method="post" action="phpFunctions.php">
<p>Please enter your birthday:
 <input type="date" name="date" id="date">
</p>
<p>Please enter your message:
 <input type="text"  name="string" id="textfield1">
</p>
<p>Please enter a number:
	<input type="number" name="number" id="number">
</p>
<p>Please enter an additional number:
	<input type="number" name="money" id="money"></p>
<p>
    <input type="submit" name="button" id="button" value="Submit" />
    <input type="reset" name="button2" id="button2" value="Reset" />
 </p>
</form> 

 </div>
 </div>
 </body>
 </html>